const pergunta = [
    {
        pergunta:"Não sei kk, dps a gente vê",
        respostas:[
            {text:"sla não sei que pergunta colocar", correta: false },
            {text:"sla2", correta: false },
            {text:"sla3", correta: true },
            {text:"sla4", correta: false },
        ]
    },
    {
        pergunta:"Não sei kk, dps a gente vê",
        respostas:[
            {text:"sla não sei que pergunta colocar", correta: false },
            {text:"sla2", correta: false },
            {text:"sla3", correta: true },
            {text:"sla4", correta: false },
        ]
    },


];